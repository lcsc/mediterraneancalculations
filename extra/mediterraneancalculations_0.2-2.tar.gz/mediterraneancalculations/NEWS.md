# MediterraneanCalculations 0.1-3

## Minor improvements and fixes
Resolution of bugs
