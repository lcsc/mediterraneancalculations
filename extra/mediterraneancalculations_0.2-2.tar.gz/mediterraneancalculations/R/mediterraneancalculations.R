#' @details Info
"_PACKAGE"
